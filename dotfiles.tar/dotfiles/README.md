Dotfiles                                                                                                                                                                    
========

A bunch of configuration files for editors and other UNIX tools.

Installation
------------

Clone this repo into `~/.dotfiles`:

    $ git clone https://git.oschina.net/coderxiaojian/dotfiles.git

Then install the dotfiles:

    $ cd ~/.dotfiles
    $ make help        # Show help message
    $ make install     # Create symblinks
    $ make deps        # Optional install system dependences like 'ctags' and 'pycscope', require root privilege
    $ make uninstall   # Restore backups and remove symblinks
    $ source ~/.bashrc
    $ source ~/.profile
    $ cp molokai.vim ~/.vim/colors

It will backup existing files as `<file>.dotfiles.bak`.

The dotfiles will be symlinked, e.g. `~/.bashrc` symlinked to `~/.dotfiles/dotfiles/bashrc`.

**Or just run `./install.sh`**

Plugins
------------
#### 插件管理
[vim-plug](https://github.com/junegunn/vim-plug#on-demand-loading-of-plugins)
#### 使用插件
- [SimpylFold](https://github.com/tmhedberg/SimpylFold): 代码折叠
- [matchit](https://github.com/vim-scripts/matchit.zip): 成对标签跳转
- [xptemplate](https://github.com/drmingdrmer/xptemplate): 代码片段补全
- [ZoomWin](https://github.com/vim-scripts/ZoomWin): 窗口全屏缩放
- [jedi-vim](https://github.com/davidhalter/jedi-vim): 代码自动补全
- [vim-unimpaired](https://github.com/tpope/vim-unimpaired): 方括号快捷键
- [vim-classpath](https://github.com/tpope/vim-classpath): 设置classpath路径
- [vim-autotags](https://github.com/craigemery/vim-autotag): 自动更新tag
- [taglist.vim](https://github.com/vim-scripts/taglist.vim): 变量函数类显示列表
- [nerdtree](https://github.com/scrooloose/nerdtree): 树形目录
- [cscopemaps.vim](https://github.com/steffanc/cscopemaps.vim): 函数变量定义调用查找
- [pyflakes.vim](https://github.com/kevinw/pyflakes-vim): python语法检查
- [vim-fugitive](https://github.com/tpope/vim-fugitive): vim集成git命令
- [vim-surround](https://github.com/tpope/vim-surround): 快速给词加环绕符号
- [Auto-Pairs](https://github.com/jiangmiao/auto-pairs): 成对符号编辑
- [molokai](https://github.com/tomasr/molokai): vim配色主题
- [ListToggle](https://github.com/Valloric/ListToggle): 显示快速修复提示
- [ctrlp.vim](https://github.com/kien/ctrlp.vim): 文件搜索
- [vim-airline](https://github.com/vim-airline/vim-airline): 状态栏显示
- [nerdcommenter](https://github.com/scrooloose/nerdcommenter): 快速注释

Usage
------------
#### 快捷键

- F2: 复制模式
- F3: 生成符号连接 
- F4: 更新符号连接
- F5: 编译文件 
- F6: 执行文件
- F7: 显示/取消行号
- F9: 显示/取消树形目录
- F10: 显示/取消变量函数类列表

#### 详细信息
参考`~/.vimrc`文件，可以对vim一些命令进行配置

