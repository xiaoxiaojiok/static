#!/bin/bash
# vim: et ts=4 sw=4
dir=`pwd`
make install
# need sudo or skip
make deps
source ~/.bashrc
source ~/.profile

if [ ! -d ~/.vim/colors ]; then                                                                                                                                                                
    mkdir -p ~/.vim/colors                                                                                                                                                                        
fi;                                                                                                                                                                                            
cp -f $dir/molokai.vim ~/.vim/colors

echo 'Done!'
